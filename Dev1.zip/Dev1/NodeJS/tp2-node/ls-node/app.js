const fs = require("fs/promises");
const path = require("path");
const fetch = require("node-fetch");
const dossier = './ls-node';

async function lsdoss(dossier){
    const ls = []
    const file = await fs.readdir(dossier, "utf-8");
    ls.push(file);
    return ls;
};

async function main(){
    try{
        const file = await lsdoss(
            path.resolve(__dirname, dossier)
        );
        

    }catch (err){
        console.error(err);
    }
}
main();