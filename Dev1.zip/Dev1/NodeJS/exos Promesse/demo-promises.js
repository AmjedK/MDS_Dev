const fs = require('fs');


function readFilePromise(path, options){
    return new Promise((resolve, reject) => {
        fs.readFile(path, options, (err, data) => {
            if(err){
                console.log('Error');
                reject('Error');
        
            }else{
                console.log(data);
                resolve(data);

        }});
    });
}
const addAsync = (lhs, rhs) =>{
    return Promise((resolve) => resolve(lhs + rhs));

};
const substracAsync = (lhs, rhs) =>{
    return Promise((resolve) => resolve(lhs - rhs));
};
const multAsync = (lhs, rhs) =>{
    return Promise((resolve) => resolve(lhs * rhs));

};
const divcAsync = (lhs, rhs) =>{
    return Promise((resolve, reject) => {
        if (rhs == 0) reject('Impossible de diviser par 0');
        else resolve(lhs / rhs);
        
    })};


module.exports = {
    addAsync,
    substracAsync,
    multAsync,
    divcAsync,
};

