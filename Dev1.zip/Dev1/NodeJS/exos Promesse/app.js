const {
    addAsync,
    substracAsync,
    multAsync,
    divcAsync,
} = require("demo-promises");
const logResult = (result) => console.log('Result is ${result}');


async function main(){
    let result = null;

    result = await addAsync(2,2);
    result = await multAsync(result, 4);
    result = await divcAsync(result, 8);
    result = await substracAsync(result, 2);
    logResult(result);
}
main();