const fs = require('fs');
//const { resolve } = require('path');
let arr = [];
async function readFilePromise(path, options){
    ((resolve, reject) =>{
        return fs.readFile(fileName, 'utf8', (err, data) =>{
            if (err) reject(err);
            else {
                for (let i =0; i < data.lenght; i++){
                    arr.Push(data[i]);

                }
                return resolve();
            }
        });

    });
    
}
readFilePromise('users.txt', 'utf8').then((data) =>{
    console.log(data);
});