const fs = require("fs/promises");
const path = require("path");
const { get } = require("http");

const { readdirSync } = require('fs');




//const chemin = '/Dev1/NodeJS/tp-node2';

 const args  =  process.argv.slice(2);
 const chemin = args[0];




async function listDoss(chemin){
    
    
    const listrep = await fs.readdir(chemin, { withFileTypes: true});
    const directory = await fs.lstat(chemin);

    if (!directory.isDirectory){
        console.log('1 : '+listrep);
        return listrep.map(dirent=>dirent.name);
        

    }else{
        console.log('2 : '+listrep);
        return listrep.map(dirent=> dirent.name+'/');

        
    } 

}



async function main(){
    try{
        let chemin2 = process.cwd();
        if (chemin){

            chemin2 = chemin;
            

        }
        const list = await listDoss(
            path.resolve(chemin2)        
        );
        console.log('Repertoire : '+list);
        

    }catch (err){
        console.error(err);
    }
    
}
main();



//----------------------------------------------------------------//

/*async function getDirectory(chemin) {
    return fs.readdirSync(chemin).filter(function (chemin) {
      return fs.statSync(chemin+'/'+chemin).isDirectory();
    });
  }*/
  


//console.log("voici la fonction getlist"+getList);

/*fs.readdir(chemin, function(err, items) {
    console.log(items);
 
    for (var i=0; i<items.length; i++) {
        console.log(items[i]);
    }
    
});*/

/*async function lsdoss(chemin){
    const ls = [];
    const listfile = await fs.readdir(chemin);
    ls.push(listfile);
    return ls;
};*/