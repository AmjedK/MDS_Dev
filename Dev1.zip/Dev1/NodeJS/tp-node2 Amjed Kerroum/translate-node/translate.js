const fs = require("fs/promises");
const path = require("path");
const fetch = require("node-fetch");


async function fetchLangage(){
    const langue = await fetch(
        'https://libretranslate.de/languages'
    );
    
    const data = await langue.text();
    return data;
    
   /* data = data.filter(function(item){    //filtrer pour enlever les "code" et "name"
         item !== "code" && "name";
    })
    return item;*/
}

async function main(){
    const langages = await fetchLangage();

    
    console.log('Voici toutes les langues supportées par l API :'+langages);

}
main();