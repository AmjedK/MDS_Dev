Dans un PowerShell en mode admin
https://docs.microsoft.com/fr-fr/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.1
> Set-ExecutionPolicy Unrestricted


[LAUNCH]
http-server . -c-1