import Zoo from "src/domain/zoo.js";

export default class ZooUi{

    zoo:Zoo;
    private html:HTMLElement;

    constructor(zoo: Zoo, elementId:string){
        this.zoo = zoo;
        this.html = document.getElementById(elementId);


    }
    /**
     * Affiche l'UI
     */
    render() {
        

    }


}