import Enclos from "src/domain/enclos";
import EAnimal from "src/domain/enum/e-animals";
import AnimalService from "./animal-service";

export default class EnclosService {

    private static MOCK = [
        {
            animaux:[
                EAnimal.Lion,
                EAnimal.Elephant,
                EAnimal.Tigre

                
            ]
        }
    ];
    private readonly serviceAnimal: AnimalService;
    constructor(serviceAnimal:AnimalService){
        this.serviceAnimal = serviceAnimal;

    }
    fetch(): Enclos[]{
        let animal = this.serviceAnimal.fetch();
        let enclos = [];
        let parc = [];
        EnclosService.MOCK.forEach(JSON =>{
            let enclos = new Enclos();
            JSON.animaux.forEach(element => {
                let trouve = animal.find(animals => animals.type == type);
                
                
                
            });
            parc.push(enclos);

        });
        return enclos;
    }
    
    
}