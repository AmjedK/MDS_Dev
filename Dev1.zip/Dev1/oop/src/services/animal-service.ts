import Animal from "src/domain/animal";
import Carnivore from "src/domain/animal/carnivore";
import Herbivore from "src/domain/animal/herbivore";
import EAnimal from "src/domain/enum/e-animals";
import ERegime from "src/domain/enum/e-regime";

export default class AnimalService {

    private static MOCK = [
        {
            regime: ERegime.Foin,
            type: EAnimal.Elephant
        },
        {
            type: EAnimal.Lion,
            regime: ERegime.Viande,
            proies:[
                EAnimal.Singe,
                EAnimal.Zèbres
            ]
        }

    ];
    fetch(): Animal[]{
        
        return AnimalService.MOCK.map(JSON => {
            let animal:Animal;
            switch(JSON.type){
                case EAnimal.Elephant:
                    animal = new Herbivore(JSON.type, JSON.regime);
                    break;
                case EAnimal.Lion:
                    animal = new Carnivore(JSON.type, JSON.regime, JSON.proies);
                    break;
            }
            return  animal;
            
            
        });
        
    }

}
