import Animal from "../animal.js";

export default class Herbivore extends Animal {
        

}