import Animal from "../animal.js";
import EAnimal from "../enum/e-animals.js";
import ERegime from "../enum/e-regime.js";

export default class Carnivore extends Animal {   
    private _proies:EAnimal[];

    constructor(type:EAnimal, regime:ERegime,proies:EAnimal[]){
        super(type,regime)
        this._proies = proies;
}
    proie():EAnimal[]{
        return this._proies;
        

    }

}