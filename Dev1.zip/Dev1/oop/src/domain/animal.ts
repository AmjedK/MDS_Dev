import EAnimal from "./enum/e-animals.js";
import ERegime from "./enum/e-regime.js";

export default class Animal {

    private _type:EAnimal;
    private _regime:ERegime;
    
    constructor(type:EAnimal, regime:ERegime){
        this._type = type;
        this._regime = regime;

    }

    type(): EAnimal{
        return this._type;

    }
    
    
    regime(): ERegime{
        return this._regime;

    }
        
    eat(){
        console.log("Je graille miam");
    }

}