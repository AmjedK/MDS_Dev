import Enclos from "./enclos.js";

export default class Zoo {
    readonly enclos: Enclos[];

    constructor(){
        this.enclos = [];
    }
        

}