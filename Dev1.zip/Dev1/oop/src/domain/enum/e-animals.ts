export enum EAnimal {
    Elephant,
    Lion,
    Tigre,
    Panthère,
    Singe,
    Crocodile,
    Zèbres,
    Hippopotame

}
export default EAnimal;