export enum ERegime {
    Viande,
    Foin,
    Insectes,
    Fruits

}
export default ERegime;