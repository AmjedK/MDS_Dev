import Animal from "./animal.js";

export default class Enclos {
   readonly animaux: Animal[];

    constructor(){
        this.animaux = [];
    }

}