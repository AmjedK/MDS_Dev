import Animal from "./animal.js";

export default class Nature {
    
     readonly animaux:Animal[];
     constructor(){
         this.animaux = [];
     }
        

}