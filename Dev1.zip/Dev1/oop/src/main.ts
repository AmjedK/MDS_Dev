import Zoo from "./domain/zoo.js";
import ZooUi from "./ui/zoo_ui.js";
window.addEventListener("load",() => {
    let zoo = new Zoo();
    let zooUi = new ZooUi(zoo, "main");
    //Affichage de l'IHM
    zooUi.render();

    
});
