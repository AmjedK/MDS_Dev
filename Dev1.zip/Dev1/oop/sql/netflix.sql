-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema netflix
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema netflix
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `netflix` DEFAULT CHARACTER SET utf8 ;
USE `netflix` ;

-- -----------------------------------------------------
-- Table `netflix`.`Subscribe`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Subscribe` (
  `idSubscribe` INT NOT NULL AUTO_INCREMENT,
  `Package` VARCHAR(45) NOT NULL,
  `Price` INT NOT NULL,
  PRIMARY KEY (`idSubscribe`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`User` (
  `idUser` INT NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(255) NOT NULL,
  `LastName` VARCHAR(255) NOT NULL,
  `Email` VARCHAR(255) NOT NULL,
  `Password` VARCHAR(45) NOT NULL,
  `Subscribe_idSubscribe` INT NOT NULL,
  PRIMARY KEY (`idUser`),
  INDEX `fk_User_Subscribe1_idx` (`Subscribe_idSubscribe` ASC),
  CONSTRAINT `fk_User_Subscribe1`
    FOREIGN KEY (`Subscribe_idSubscribe`)
    REFERENCES `netflix`.`Subscribe` (`idSubscribe`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Caracteristic`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Caracteristic` (
  `idCaracteristic` INT NOT NULL AUTO_INCREMENT,
  `Categorie` VARCHAR(45) NOT NULL,
  `Title` VARCHAR(255) NOT NULL,
  `Description` VARCHAR(255) NOT NULL,
  `Mark` INT NOT NULL,
  PRIMARY KEY (`idCaracteristic`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Casting`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Casting` (
  `idCasting` INT NOT NULL AUTO_INCREMENT,
  `Nom_Realisateur` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idCasting`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Movie`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Movie` (
  `idMovie` INT NOT NULL AUTO_INCREMENT,
  `duration` INT NOT NULL,
  `ReleaseM` DATE NOT NULL,
  `Casting_idCasting` INT NOT NULL,
  `Caracteristic_idCaracteristic` INT NOT NULL,
  PRIMARY KEY (`idMovie`),
  INDEX `fk_Movie_Casting1_idx` (`Casting_idCasting` ASC),
  INDEX `fk_Movie_Caracteristic1_idx` (`Caracteristic_idCaracteristic` ASC),
  CONSTRAINT `fk_Movie_Casting1`
    FOREIGN KEY (`Casting_idCasting`)
    REFERENCES `netflix`.`Casting` (`idCasting`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Movie_Caracteristic1`
    FOREIGN KEY (`Caracteristic_idCaracteristic`)
    REFERENCES `netflix`.`Caracteristic` (`idCaracteristic`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`serie`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`serie` (
  `idserie` INT NOT NULL AUTO_INCREMENT,
  `Nb_episode` INT NOT NULL,
  `Nb_season` INT NOT NULL,
  `ReleaseS` DATE NOT NULL,
  `Casting_idCasting` INT NOT NULL,
  `Caracteristic_idCaracteristic` INT NOT NULL,
  PRIMARY KEY (`idserie`),
  INDEX `fk_serie_Casting1_idx` (`Casting_idCasting` ASC),
  INDEX `fk_serie_Caracteristic1_idx` (`Caracteristic_idCaracteristic` ASC),
  CONSTRAINT `fk_serie_Casting1`
    FOREIGN KEY (`Casting_idCasting`)
    REFERENCES `netflix`.`Casting` (`idCasting`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_serie_Caracteristic1`
    FOREIGN KEY (`Caracteristic_idCaracteristic`)
    REFERENCES `netflix`.`Caracteristic` (`idCaracteristic`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`List`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`List` (
  `idList` INT NOT NULL AUTO_INCREMENT,
  `Movie_idMovie`  INT NULL,
  `serie_idserie` INT NULL,
  `User_idUser` INT NOT NULL,
  PRIMARY KEY (`idList`),
  INDEX `fk_List_Movie1_idx` (`Movie_idMovie` ASC),
  INDEX `fk_List_serie1_idx` (`serie_idserie` ASC),
  INDEX `fk_List_User1_idx` (`User_idUser` ASC),
  CONSTRAINT `fk_List_Movie1`
    FOREIGN KEY (`Movie_idMovie`)
    REFERENCES `netflix`.`Movie` (`idMovie`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_List_serie1`
    FOREIGN KEY (`serie_idserie`)
    REFERENCES `netflix`.`serie` (`idserie`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_List_User1`
    FOREIGN KEY (`User_idUser`)
    REFERENCES `netflix`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Favorite`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Favorite` (
  `idFavorite` INT NOT NULL AUTO_INCREMENT,
  `Movie_idMovie` INT NULL,
  `serie_idserie` INT NULL,
  `User_idUser` INT NOT NULL,
  PRIMARY KEY (`idFavorite`),
  INDEX `fk_Favorite_Movie1_idx` (`Movie_idMovie` ASC),
  INDEX `fk_Favorite_serie1_idx` (`serie_idserie` ASC),
  INDEX `fk_Favorite_User1_idx` (`User_idUser` ASC),
  CONSTRAINT `fk_Favorite_Movie1`
    FOREIGN KEY (`Movie_idMovie`)
    REFERENCES `netflix`.`Movie` (`idMovie`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Favorite_serie1`
    FOREIGN KEY (`serie_idserie`)
    REFERENCES `netflix`.`serie` (`idserie`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Favorite_User1`
    FOREIGN KEY (`User_idUser`)
    REFERENCES `netflix`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Actor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Actor` (
  `idActor` INT NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  `Age` INT NOT NULL,
  PRIMARY KEY (`idActor`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `netflix`.`Actor_has_Casting`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix`.`Actor_has_Casting` (
  `Actor_idActor` INT NOT NULL,
  `Casting_idCasting` INT NOT NULL,
  PRIMARY KEY (`Actor_idActor`, `Casting_idCasting`),
  INDEX `fk_Actor_has_Casting_Casting1_idx` (`Casting_idCasting` ASC),
  INDEX `fk_Actor_has_Casting_Actor1_idx` (`Actor_idActor` ASC),
  CONSTRAINT `fk_Actor_has_Casting_Actor1`
    FOREIGN KEY (`Actor_idActor`)
    REFERENCES `netflix`.`Actor` (`idActor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Actor_has_Casting_Casting1`
    FOREIGN KEY (`Casting_idCasting`)
    REFERENCES `netflix`.`Casting` (`idCasting`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
