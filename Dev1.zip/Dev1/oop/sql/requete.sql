-- ------------------------------- ---- ------------------------------- ---- ------------------------------- --

-- ------------------------------- --
-- REQUETE SQL  -- 
-- ------------------------------- --

-- ------------------------------- ---- ------------------------------- ---- ------------------------------- --


-- ------------------------------- --
-- INNER JOIN --
-- TABLE CARACTERISTIC + MOVIE
-- ------------------------------- --
select *
from caracteristic 
inner join movie 
where caracteristic.idCaracteristic = movie.Caracteristic_idCaracteristic;
*

-- ------------------------------- --
-- LEFT JOIN --
-- TABLE USER + LIST MOVIE PREFERE
-- ------------------------------- --

select user.FirstName ,list.Movie_idMovie  from `user` 
left join list on user.idUser = list.Movie_idMovie;


-- ------------------------------- --
-- GROUP BY ET HAVING --
-- RECUPERER LE TITRE DES FILMS AVEC UNE NOTES SUPERIEUR A 3
-- ------------------------------- --

select caracteristic.title, MAX(caracteristic.Mark) as Meilleur_note
from caracteristic
group by Title 
having MAX(caracteristic.Mark) >3;
