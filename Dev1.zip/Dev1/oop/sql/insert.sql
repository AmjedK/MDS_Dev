
-- ------------------------------- --
-- TABLE ACTEUR --
-- ------------------------------- --
INSERT INTO netflix.actor (FirstName, LastName , Age)
 VALUES
 ('Jamie', 'Lee Curtis', 62),
 ('Judy', 'Greer', 46),
 ('Bryan', 'Cranston',65),
 ('Aaron', 'Paul',42),
 ('Emilia','Clarke', 34),
 ('Kit','Harington',34);

 -- ------------------------------- --
-- TABLE CASTING -- 
-- ------------------------------- --
INSERT INTO netflix.casting (Nom_Realisateur)
 VALUES
 ('David Gordon Green'),
 ('Vince Gilligan'),
 ('Mark Huffam;Frank Doelger');



-- ------------------------------- --
-- TABLE CARACTERISTIC --
-- ------------------------------- --
 INSERT INTO netflix.caracteristic (Categorie, Title , Description, Mark)
 VALUES
 (	
 	'Horreur', 
 	'Halloween', 
 	'Cela fait 40 ans que Laurie Strode a survécu à une attaque de Michael Myers le soir d Halloween. 
	 Enfermé dans une institution, Myers parvient à s échapper lorsque son transfert en bus tourne terriblement mal.', 
	3
 ),
 (
 	'Drame', 
 	'Breakin Bad', 
 	'Walter White, 50 ans, est professeur de chimie dans un lycée du Nouveau-Mexique. Pour réunir de 
     l argent afin de subvenir aux besoins de sa famille, Walter met ses connaissances en chimie à profit pour fabriquer et vendre du crystal meth.', 
	5
 ),
 (
 	'Fantasy;Drame', 
 	'Game of thrones',
 	'Neuf familles nobles rivalisent pour le contrôle du Trône de Fer dans les sept royaumes de Westeros. Pendant ce temps, 
	 des anciennes créatures mythiques oubliées reviennent pour faire des ravages.',
	 4
);



-- ------------------------------- --
-- TABLE MOVIE -- 
-- ------------------------------- --

INSERT INTO netflix.movie (duration, ReleaseM, Casting_idCasting, Caracteristic_idCaracteristic)
VALUES 
(120, '2019-10-22', 2, 2), 
(140, '2021-06-02', 1, 2);



-- ------------------------------- --
-- TABLE SERIE -- 
-- ------------------------------- --
 INSERT INTO netflix.serie (Nb_episode, Nb_season, ReleaseS, Casting_idCasting, Caracteristic_idCaracteristic)
 VALUES
 (62, 5, '2008-01-20', 2, 2 ),
 (73, 8, '2011-04-17', 3, 3 );



-- ------------------------------- --
-- TABLE SUBSCRIBE -- 
-- ------------------------------- --
INSERT INTO netflix.subscribe (Package, Price)
VALUES 
('basique', 10), 
('student', 7), 
('family', 18);

-- ------------------------------- --
-- TABLE USER -- 
-- ------------------------------- --

INSERT INTO netflix.user (FirstName, LastName, Email, Password, Subscribe_idSubscribe)
VALUES 
('Julien', 'Dupont', 'julien.dupont@gmail.com', 'juliendupont', 1),
('Marine', 'Pointu', 'marine.pointu@gmail.com', 'marinepointu', 2),
('Théo', 'Jean', 'theo.jean@gmail.com', 'theojean', 1);


-- ------------------------------- --
-- TABLE ACTOR HAS CASTING -- 
-- ------------------------------- --
INSERT INTO netflix.actor_has_casting (Actor_idActor, Casting_idCasting)
VALUES 
(3, 2);

-- ------------------------------- --
-- TABLE LIST -- 
-- ------------------------------- --
INSERT INTO netflix.list (Movie_idMovie,serie_idserie, User_idUser)
VALUES 
(1, 1, 2), 
(null, null, 1), 
(1, null, 3);

-- ------------------------------- --
-- TABLE FAVORITE -- 
-- ------------------------------- --
INSERT INTO netflix.favorite (User_idUser, Movie_idMovie, serie_idSerie)
VALUES 
(1, 1, 2),
(3, 1, 1);





