export default class Zoo {
    capitalize(a) {
        let sentence = a;
        return sentence
            .split(" ")
            .map(word => `${word.charAt(0).toUpperCase()}${word.substr(1).toLowerCase()}`)
            .join(" ");
    }
    syracuse(n) {
        let loops = 0;
        let nb = n;
        let res = [];
        while (nb != 1) {
            if (nb % 2 === 0) {
                loops++;
                nb = nb / 2;
                // console.log(nb);
                res.push(nb);
            }
            else {
                loops++;
                nb = nb * 3 + 1;
                //console.log(nb);
                res.push(nb);
            }
        }
        return [loops, res];
    }
    scan(n) {
        let tab = [];
        for (let i = 1; i <= n; i++) {
            let [loops, res] = this.syracuse(i);
            tab.push(console.log(`${i}:${this.syracuse(i)}`));
        }
        return tab;
    }
}
