export default class ZooUi {
    constructor(zoo, elementId) {
        this.zoo = zoo;
        this.html = document.getElementById(elementId);
    }
    /**
     * Affiche l'UI
     */
    render() {
        let a = 20;
        //let rep = Math.random();
        // this.zoo.syracuse(a);
        /*  let recups = this.zoo.scan(a);
          let ul = document.createElement("ul");
          for (let recup of recups){
              let li = document.createElement("li");
              li.innerHTML = recup;
              ul.appendChild(li);
  
          }
          this.html.innerHTML="";
          this.html.appendChild(ul);
          
           */
        this.html.innerHTML = this.zoo.capitalize("hello world we are realy happy today");
    }
}
