const generateItem = (id, content) => {
  const newListElement = document.createElement('li');
  const deleteElement = document.createElement('i');
  newListElement.id = `item-${id}`;

  
  newListElement.innerHTML = `<input type="checkbox" class="mark-item" id="mark-item-${id}" data-item-id="${id}">
        <label for="mark-item-${id}">${content}</label>
        <button id="delete-item-${id}">Delete</button>`;

  return newListElement;
};

const addItem = () => {
  const itemsListEl = document.querySelector('#items-list');
  const inputValue = document.querySelector('#add-item-input').value;
  const listElementsCount = itemsListEl.childElementCount;

  itemsListEl.append(generateItem(listElementsCount + 1, inputValue));
};

const checkItem = (e) => {
  const { itemId } = e.currentTarget.dataset;
  document.querySelector(`#item-${itemId} > label`).classList.add('line-through');
};
const deleteItem = () =>{
  if (document.target.classList.contains('delete-todo')){
    const itemsListEl = document.target.parentElement.dataset.key;
    deleteItem(itemsListEl);
  }
  
}
document.querySelector('deleteBtn').addEventListener('click', deleteItem);
document.querySelector('add-item-button').addEventListener('click', addItem);

document.querySelectorAll('.mark-item').forEach((checkbox) => {
  checkbox.addEventListener('click', checkItem);
});
