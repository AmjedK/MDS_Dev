# simple-todo

Install dependencies using: `npm install`

Run the project using this command: `npm run start`
