SELECT nom_burger FROM burger, commande_has_burger, commande 
WHERE id_burger = burger_id_burger 
AND commande_id_commande = id_commande 
AND id_commande = 1
-- Tous les burgers de la commande 1

SELECT * FROM fournisseur, produit, fournisseur_has_produits 
WHERE id_produit = produit_id_produit 
AND fournisseur_id_fournisseur = id_fournisseur 
AND type_produit = "pain";
-- Tous les fournisseurs de pain

SELECT * FROM client 
LEFT JOIN commande 
ON id_client = commande.client_id_client
-- Affiche tous les clients (même ceux qui sont reliés à aucune commande)


SELECT type_produit, 
SUM(prix_produit) FROM produit 
GROUP BY type_produit;
-- Affiche la somme de chaque type de produit acheté

SELECT type_produit, SUM(prix_produit) 
FROM produit 
GROUP BY type_produit 
HAVING sum(prix_produit) > 10;
-- Affiche la somme de chaque type de produit acheté, si elle est supérieur à 10€

SELECT nom_employe, prenom_employe, poste_employe 
FROM employe, commande_has_employe, commande 
WHERE id_employe = employe_id_employe 
AND commande_id_commande = id_commande 
AND id_commande = 1
-- Affiche tous les employés qui ont travaillé sur la commande 1


-- Calculer le prix de revient de la commande 1 (prix de vente - cout de production du produit)

-- Afficher le burger le plus vendu 

-- Afficher l'employé du mois (celui qui a travaillé sur le plus de commande)

-- Afficher l'employé le plus agé, son salaire, et le produit sur lequel il travaille le plus

-- 



