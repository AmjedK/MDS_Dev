INSERT INTO  Fast_food.fast_food values(NULL, '15 rue du paradis 38000 Burger');

INSERT INTO  Fast_food.Employe VALUES(NULL, "Dubois", "John", "CDI", 2100, '1992-02-04', "livreur", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Fast", "Jean", "CDI", 2100, '1992-02-07', "livreur", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Dupuis", "Lucette", "Interim", 3600, '1978-02-08', "cuisinier", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Coquelicot", "Pierre", "CDD", 2700, '1984-07-14', "Vendeur", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Horloge", "Philippe", "CDI", 2100, '1988-12-12', "agent d'entretien", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Bouteille", "Mireille", "CDD", 6700, '1942-09-12', "agent d'entretien", 1 );
INSERT INTO  Fast_food.Employe VALUES(NULL, "Souris", "Louis", "Interim", 4352, '1949-06-14', "cuisinier", 1 );

INSERT INTO  Fast_food.Menu VALUES(NULL, "petite faim", 5 );
INSERT INTO  Fast_food.Menu VALUES(NULL, "grosse dalle", 8 );
INSERT INTO  Fast_food.Menu VALUES(NULL, "moyen",6);
INSERT INTO  Fast_food.Menu VALUES(NULL, "kids", 4);
INSERT INTO  Fast_food.Menu VALUES(NULL, "du jour", 5 );

INSERT INTO  Fast_food.Burger VALUES(NULL, "little",4 , 1 );
INSERT INTO  Fast_food.Burger VALUES(NULL, "big burger",7 , 2 );
INSERT INTO  Fast_food.Burger VALUES(NULL, "medium burger",5 , 3 );
INSERT INTO  Fast_food.Burger VALUES(NULL, "kidiburger",3 , 4 );
INSERT INTO  Fast_food.Burger VALUES(NULL, "burger du jour",4 , 5 );

INSERT INTO  Fast_food.Boisson VALUES(NULL, "Eau petillante aromatisée",2 , 1 );
INSERT INTO  Fast_food.Boisson VALUES(NULL, "Coca cola",3 , 2 );
INSERT INTO  Fast_food.Boisson VALUES(NULL, "Ice tea",2.5 , 3 );
INSERT INTO  Fast_food.Boisson VALUES(NULL, "Sirop barbapapa",2 , 4 );
INSERT INTO  Fast_food.Boisson VALUES(NULL, "Thé glacé maison",3 , 5 );

INSERT INTO Fast_food.Commande VALUES
(NULL, 7.75, '2021-10-22','Sur place', 3),
(NULL, 12.25, '2021-10-21', 'Sur place', 2),
(NULL, 26.37, '2021-10-22', 'A emporter', 1),
(NULL, 6.00, '2021-10-22', 'A emporter', 2),
(NULL, 36.21, '2021-10-22', 'Livraison', 4),
(NULL, 15.67, '2021-10-21', 'Livraison', 5);

INSERT INTO Fast_food.client ( id_client, adresse_client ) 
VALUES( NULL, "12 Rue des pissenlits 38100 Grenoble" ),
( NULL, '27 chemin des tuiles 38130 Grenoble' ),
( NULL, '156 Rue Victor hugo 38000 Grenoble' ),
( NULL, '3 Rue Jean moulin 38000 Grenoble' ),
( NULL, '68 chemin des poireaux 38000 Grenoble' ),
( NULL, '17 chemin des poireaux 38000 Grenoble' ),
( NULL, '67 chemin des carottes 38000 Grenoble' ),
( NULL, '67 chemin des patates 38000 Grenoble' );

INSERT INTO Fast_food.Produit 
VALUES(NULL,'pain',0.14,3,NULL),
(NULL,'legume',0,3,NULL),
(NULL,'boisson',1,NULL,3),
(NULL,'viande',3,3,NULL),
(NULL,'sauce',0.15,3,NULL),
(NULL,'fromage',1,3,NULL),

(NULL,'pain',0.14,1,NULL),
(NULL,'legume',0,1,NULL),
(NULL,'boisson',1,NULL,1),
(NULL,'viande',3,1,NULL),
(NULL,'sauce',0.5,1,NULL),
(NULL,'fromage',1,1,NULL),

(NULL,'pain',0.14,2,NULL),
(NULL,'legume',0,2,NULL),
(NULL,'boisson',1,NULL,2),
(NULL,'viande',3,2,NULL),
(NULL,'sauce',0.5,2,NULL),
(NULL,'fromage',1,2,NULL),

(NULL,'pain',0.14,4,NULL),
(NULL,'legume',0,4,NULL),
(NULL,'boisson',1,NULL,4),
(NULL,'viande',3,4,NULL),
(NULL,'sauce',0.5,4,NULL),
(NULL,'fromage',1,4,NULL);

INSERT INTO Fast_food.Fournisseur
VALUES(NULL,'Picard','Grenoble',98261727181722),
(NULL,'Grand fraie','Saint-martin-d-hère',01826381942016),
(NULL,'Fish','Bretagne',63436182736458),
(NULL,'Coca-cola','Parie',82635142314276),
(NULL,'Bourbon','Grenoble',82635142639787);

INSERT INTO Fast_food.Fournisseur_has_produits
VALUES(1,1),
(1,2),
(1,3),
(1,4),
(2,5),
(2,6),
(2,7),
(2,8),
(3,9),
(3,10),
(4,11),
(4,12),
(5,13),
(5,14),
(5,15),
(2,16),
(2,17),
(2,18),
(3,19),
(3,20),
(3,21),
(1,22),
(1,23);

INSERT INTO Fast_food.Commande_has_menu
VALUES(1,1),
(1,2),
(1,3),
(1,4),
(2,5),
(2,1),
(2,4),
(3,3),
(3,4),
(4,1),
(5,2),
(6,5);

INSERT INTO Fast_food.Commande_has_burger
VALUES(1,1),
(1,2),
(1,3),
(1,4),
(2,5),
(2,1),
(2,4),
(3,3),
(3,4),
(4,1),
(5,2),
(2,5);

INSERT INTO Fast_food.Commande_has_boisson
VALUES(1,1),
(1,2),
(1,3),
(1,4),
(2,5),
(2,1),
(2,4),
(3,3),
(3,4),
(4,1),
(5,2),
(2,5);

INSERT INTO Fast_food.Commande_has_employe
VALUES(1,1),
(3,1),
(5,1),
(2,2),
(7,2),
(4,3),
(7,3),
(3,4),
(6,4);