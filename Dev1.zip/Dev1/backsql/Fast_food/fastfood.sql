CREATE DATABASE IF NOT EXISTS Fast_food; 

CREATE TABLE Fast_food.fast_food (
    id_fastfood int NOT NULL AUTO_INCREMENT,
    adress varchar(255) NOT NULL,
    PRIMARY KEY(id_fastfood)
);

CREATE TABLE Fast_food.Employe (
    id_employe int NOT NULL AUTO_INCREMENT,
    nom_employe varchar(255) NOT NULL,
    prenom_employe varchar(255) NOT NULL,
    contrat_employe ENUM("CDI", "CDD", "Interim") NOT NULL,
    salairebrut_employe DECIMAL (18, 2) NOT NULL,
    datenaissance_employe DATE NOT NULL,
    poste_employe ENUM("Vendeur","agent d'entretien","cuisinier","livreur"),
    id_fastfood INT NOT NULL,
    PRIMARY KEY(id_employe)
);

CREATE TABLE Fast_food.Commande_has_employe (
    employe_id_employe int NOT NULL ,
    commande_id_commande INT NOT NULL
);

CREATE TABLE Fast_food.Commande (
    id_commande int NOT NULL AUTO_INCREMENT,
    prix_commande DECIMAL (18, 2) NOT NULL,
    date DATE NOT NULL,
    type_commande ENUM("Sur place", "A emporter", "Livraison") NOT NULL,
    client_id_client INT NOT NULL,
    PRIMARY KEY(id_commande)
);
CREATE TABLE Fast_food.Client (
    id_client int NOT NULL AUTO_INCREMENT,
    adresse_client VARCHAR (50),
    PRIMARY KEY(id_client)
);
CREATE TABLE Fast_food.Menu (
    id_menu int NOT NULL AUTO_INCREMENT,
    nom_menu VARCHAR (20) NOT NULL,
    prix_menu DECIMAL (10,2),
    PRIMARY KEY(id_menu)
);

CREATE TABLE Fast_food.Commande_has_burger (
    burger_id_burger int NOT NULL ,
    commande_id_commande INT NOT NULL
);

CREATE TABLE Fast_food.Commande_has_boisson (
    boisson_id_boisson int NOT NULL ,
    commande_id_commande INT NOT NULL
);

CREATE TABLE Fast_food.Commande_has_menu (
    menu_id_menu int NOT NULL ,
    commande_id_commande INT NOT NULL
);



CREATE TABLE Fast_food.Burger (
    id_burger int NOT NULL AUTO_INCREMENT,
    nom_burger VARCHAR (20) NOT NULL,
    prix_burger DECIMAL (10, 2),
    menu_id_menu INT,
    PRIMARY KEY(id_burger)
);


CREATE TABLE Fast_food.Boisson (
    id_boisson int NOT NULL AUTO_INCREMENT,
    nom_boisson VARCHAR (30),
    prix_boisson DECIMAL (10, 2),
    menu_id_menu INT,
    PRIMARY KEY(id_boisson)
);


CREATE TABLE Fast_food.Produit (
    id_produit int NOT NULL AUTO_INCREMENT,
    type_produit ENUM("pain", "legume", "viande", "sauce", "fromage", "boisson"),
    prix_produit DECIMAL (10, 2),
    burger_id_burger INT,
    boisson_id_boisson INT, 
    PRIMARY KEY(id_produit)
);
CREATE TABLE Fast_food.Fournisseur (
    id_fournisseur int NOT NULL AUTO_INCREMENT,
    nom_fournisseur VARCHAR(20),
    adresse_fournisseur VARCHAR(50),
    siret_fournisseur VARCHAR(14),
    PRIMARY KEY(id_fournisseur)
);
CREATE TABLE Fast_food.Fournisseur_has_produits (
    fournisseur_id_fournisseur INT NOT NULL,
    produit_id_produit INT NOT NULL
);


